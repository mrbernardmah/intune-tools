#Requires -Version 5.1
<#
    IntuneTools - a light "right click tools" toolkit for Microsoft Intune.
    All calls go through Microsoft Graph via Invoke-MgGraphRequest
    (only the Microsoft.Graph.Authentication module is required).
#>

Set-StrictMode -Off

$script:GraphBase   = 'https://graph.microsoft.com'
$script:ClientName  = 'IntuneTools'
$script:ClientVer   = '0.1.0'

$script:DefaultScopes = @(
    'DeviceManagementManagedDevices.ReadWrite.All'
    'DeviceManagementManagedDevices.PrivilegedOperations.All'
    'DeviceManagementConfiguration.Read.All'
    'Device.Read.All'
    'GroupMember.ReadWrite.All'
    'BitLockerKey.Read.All'
    'DeviceLocalCredential.Read.All'
)

# Action catalogue: name -> Graph action, API version, body, whether it is destructive.
$script:Actions = [ordered]@{
    Sync               = @{ Path = 'syncDevice';                        Api = 'v1.0'; Body = $null;                                  Destructive = $false; Label = 'Sync device' }
    Restart            = @{ Path = 'rebootNow';                         Api = 'v1.0'; Body = $null;                                  Destructive = $false; Label = 'Restart' }
    Shutdown           = @{ Path = 'shutDown';                          Api = 'v1.0'; Body = $null;                                  Destructive = $false; Label = 'Shut down' }
    QuickScan          = @{ Path = 'windowsDefenderScan';               Api = 'v1.0'; Body = @{ quickScan = $true };                 Destructive = $false; Label = 'Defender quick scan' }
    FullScan           = @{ Path = 'windowsDefenderScan';               Api = 'v1.0'; Body = @{ quickScan = $false };                Destructive = $false; Label = 'Defender full scan' }
    UpdateDefender     = @{ Path = 'windowsDefenderUpdateSignatures';   Api = 'v1.0'; Body = $null;                                  Destructive = $false; Label = 'Update Defender signatures' }
    CollectDiagnostics = @{ Path = 'createDeviceLogCollectionRequest';  Api = 'beta'; Body = @{ templateType = @{ templateType = 'predefined' } }; Destructive = $false; Label = 'Collect diagnostics' }
    RotateLAPS         = @{ Path = 'rotateLocalAdminPassword';          Api = 'beta'; Body = $null;                                  Destructive = $false; Label = 'Rotate LAPS password' }
    RotateBitLocker    = @{ Path = 'rotateBitLockerKeys';               Api = 'beta'; Body = $null;                                  Destructive = $false; Label = 'Rotate BitLocker keys' }
    Locate             = @{ Path = 'locateDevice';                      Api = 'v1.0'; Body = $null;                                  Destructive = $false; Label = 'Locate device' }
    Retire             = @{ Path = 'retire';                            Api = 'v1.0'; Body = $null;                                  Destructive = $true;  Label = 'Retire' }
    Wipe               = @{ Path = 'wipe';                              Api = 'v1.0'; Body = @{ keepEnrollmentData = $false; keepUserData = $false }; Destructive = $true; Label = 'Wipe (factory reset)' }
    FreshStart         = @{ Path = 'cleanWindowsDevice';                Api = 'v1.0'; Body = @{ keepUserData = $true };              Destructive = $true;  Label = 'Fresh Start (keep user data)' }
    AutopilotReset     = @{ Path = 'wipe';                              Api = 'v1.0'; Body = @{ keepEnrollmentData = $true; keepUserData = $false }; Destructive = $true; Label = 'Autopilot Reset' }
}

#region Helpers ---------------------------------------------------------------

function Assert-ITConnected {
    if (-not (Get-Command Get-MgContext -ErrorAction SilentlyContinue) -or -not (Get-MgContext)) {
        throw 'Not connected. Run Connect-IntuneTools first.'
    }
}

function Invoke-ITGraph {
    <# Thin wrapper around Invoke-MgGraphRequest with paging and the client headers
       that the BitLocker / LAPS endpoints require. #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Uri,
        [ValidateSet('GET','POST','PATCH','DELETE')][string]$Method = 'GET',
        [object]$Body,
        [ValidateSet('v1.0','beta')][string]$Api = 'v1.0',
        [switch]$All
    )
    Assert-ITConnected
    $full = if ($Uri -match '^https://') { $Uri } else { "$script:GraphBase/$Api/$($Uri.TrimStart('/'))" }
    $params = @{
        Uri     = $full
        Method  = $Method
        Headers = @{ 'ocp-client-name' = $script:ClientName; 'ocp-client-version' = $script:ClientVer; ConsistencyLevel = 'eventual' }
        OutputType = 'PSObject'
        ErrorAction = 'Stop'
    }
    if ($null -ne $Body) { $params.Body = ($Body | ConvertTo-Json -Depth 10 -Compress); $params.ContentType = 'application/json' }

    $resp = Invoke-MgGraphRequest @params
    if (-not $All) { return $resp }

    $items = [System.Collections.Generic.List[object]]::new()
    while ($resp) {
        if ($resp.PSObject.Properties['value']) { foreach ($v in $resp.value) { $items.Add($v) } }
        $next = if ($resp.PSObject.Properties['@odata.nextLink']) { $resp.'@odata.nextLink' } else { $null }
        if (-not $next) { break }
        $params.Uri = $next
        $resp = Invoke-MgGraphRequest @params
    }
    return $items
}

function ConvertTo-ITDevice {
    param([Parameter(ValueFromPipeline)]$Raw)
    process {
        [pscustomobject]@{
            PSTypeName         = 'IntuneTools.Device'
            DeviceName         = $Raw.deviceName
            User               = $Raw.userPrincipalName
            OS                 = $Raw.operatingSystem
            OSVersion          = $Raw.osVersion
            Compliance         = $Raw.complianceState
            LastSync           = if ($Raw.lastSyncDateTime) { ([datetime]$Raw.lastSyncDateTime).ToLocalTime() } else { $null }
            Ownership          = $Raw.managedDeviceOwnerType
            Model              = $Raw.model
            Manufacturer       = $Raw.manufacturer
            SerialNumber       = $Raw.serialNumber
            Encrypted          = $Raw.isEncrypted
            ManagementAgent    = $Raw.managementAgent
            Id                 = $Raw.id
            AzureADDeviceId    = $Raw.azureADDeviceId
        }
    }
}

$script:DeviceSelect = 'id,deviceName,userPrincipalName,operatingSystem,osVersion,complianceState,lastSyncDateTime,managedDeviceOwnerType,model,manufacturer,serialNumber,isEncrypted,managementAgent,azureADDeviceId'

#endregion

#region Connection ------------------------------------------------------------

function Connect-IntuneTools {
    <#
    .SYNOPSIS  Sign in to Microsoft Graph with the scopes IntuneTools needs.
    .EXAMPLE   Connect-IntuneTools
    .EXAMPLE   Connect-IntuneTools -TenantId contoso.onmicrosoft.com -ReadOnly
    #>
    [CmdletBinding()]
    param(
        [string]$TenantId,
        [string[]]$Scopes = $script:DefaultScopes,
        [switch]$ReadOnly,
        [switch]$UseDeviceCode
    )
    if (-not (Get-Module -ListAvailable Microsoft.Graph.Authentication)) {
        throw "Microsoft.Graph.Authentication is not installed. Run: Install-Module Microsoft.Graph.Authentication -Scope CurrentUser"
    }
    Import-Module Microsoft.Graph.Authentication -ErrorAction Stop
    if ($ReadOnly) {
        $Scopes = @('DeviceManagementManagedDevices.Read.All','DeviceManagementConfiguration.Read.All','Device.Read.All','GroupMember.Read.All')
    }
    $p = @{ Scopes = $Scopes; NoWelcome = $true }
    if ($TenantId)      { $p.TenantId = $TenantId }
    if ($UseDeviceCode) { $p.UseDeviceCode = $true }
    Connect-MgGraph @p | Out-Null
    $ctx = Get-MgContext
    Write-Verbose "Connected to tenant $($ctx.TenantId) as $($ctx.Account)"
    $ctx
}

function Disconnect-IntuneTools { Disconnect-MgGraph | Out-Null }

#endregion

#region Device lookup ---------------------------------------------------------

function Get-ITDevice {
    <#
    .SYNOPSIS  Find Intune managed devices by name, user, serial, Id or Entra group.
    .EXAMPLE   Get-ITDevice -Name LAPTOP-
    .EXAMPLE   Get-ITDevice -User jane@contoso.com
    .EXAMPLE   Get-ITDevice -GroupName 'Pilot Devices'
    #>
    [CmdletBinding(DefaultParameterSetName = 'Name')]
    param(
        [Parameter(ParameterSetName = 'Name', Position = 0)][string]$Name,
        [Parameter(ParameterSetName = 'User')][string]$User,
        [Parameter(ParameterSetName = 'Serial')][string]$SerialNumber,
        [Parameter(ParameterSetName = 'Id', ValueFromPipelineByPropertyName)][string[]]$Id,
        [Parameter(ParameterSetName = 'Group')][string]$GroupName,
        [Parameter(ParameterSetName = 'Group')][string]$GroupId,
        [ValidateSet('Windows','macOS','iOS','Android','Any')][string]$OS = 'Any',
        [int]$Top = 0
    )
    process {
        switch ($PSCmdlet.ParameterSetName) {
            'Id' {
                foreach ($i in $Id) {
                    Invoke-ITGraph -Uri "deviceManagement/managedDevices/$i`?`$select=$script:DeviceSelect" | ConvertTo-ITDevice
                }
                return
            }
            'Group' {
                Get-ITGroupManagedDevice -GroupName $GroupName -GroupId $GroupId
                return
            }
        }

        $filters = @()
        if ($Name)         { $filters += "startswith(deviceName,'$($Name.Replace("'","''"))')" }
        if ($User)         { $filters += "userPrincipalName eq '$($User.Replace("'","''"))'" }
        if ($SerialNumber) { $filters += "serialNumber eq '$($SerialNumber.Replace("'","''"))'" }
        if ($OS -ne 'Any') { $filters += "operatingSystem eq '$OS'" }

        $q = "deviceManagement/managedDevices?`$select=$script:DeviceSelect"
        if ($filters) { $q += '&$filter=' + [uri]::EscapeDataString($filters -join ' and ') }
        if ($Top -gt 0) {
            $q += "&`$top=$Top"
            (Invoke-ITGraph -Uri $q).value | ConvertTo-ITDevice
        } else {
            Invoke-ITGraph -Uri $q -All | ConvertTo-ITDevice
        }
    }
}

function Get-ITGroupManagedDevice {
    <# Resolve an Entra group (the Intune equivalent of a ConfigMgr collection) to its Intune managed devices.
       Includes nested groups and devices of user members. #>
    [CmdletBinding()]
    param([string]$GroupName, [string]$GroupId)
    if (-not $GroupId) {
        if (-not $GroupName) { throw 'Specify -GroupName or -GroupId.' }
        $g = (Invoke-ITGraph -Uri ("groups?`$filter=" + [uri]::EscapeDataString("displayName eq '$($GroupName.Replace("'","''"))'") + '&$select=id,displayName')).value
        if (-not $g) { throw "Group '$GroupName' not found." }
        if (@($g).Count -gt 1) { throw "More than one group named '$GroupName'; use -GroupId." }
        $GroupId = $g[0].id
    }

    $seen = @{}
    # Device members
    $devs = Invoke-ITGraph -Uri "groups/$GroupId/transitiveMembers/microsoft.graph.device?`$select=deviceId,displayName" -All
    foreach ($d in $devs) {
        if (-not $d.deviceId) { continue }
        $md = (Invoke-ITGraph -Uri ("deviceManagement/managedDevices?`$select=$script:DeviceSelect&`$filter=" + [uri]::EscapeDataString("azureADDeviceId eq '$($d.deviceId)'"))).value
        foreach ($m in @($md)) { if ($m -and -not $seen[$m.id]) { $seen[$m.id] = $true; $m | ConvertTo-ITDevice } }
    }
    # User members -> their managed devices
    $users = Invoke-ITGraph -Uri "groups/$GroupId/transitiveMembers/microsoft.graph.user?`$select=id,userPrincipalName" -All
    foreach ($u in $users) {
        $md = Invoke-ITGraph -Uri "users/$($u.id)/managedDevices?`$select=$script:DeviceSelect" -All
        foreach ($m in @($md)) { if ($m -and -not $seen[$m.id]) { $seen[$m.id] = $true; $m | ConvertTo-ITDevice } }
    }
}

function Get-ITDeviceDetail {
    <# Full managedDevice record (beta, includes hardware info) for one device. #>
    [CmdletBinding()]
    param([Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$Id)
    process { Invoke-ITGraph -Api beta -Uri "deviceManagement/managedDevices/$Id`?`$select=*,hardwareInformation" }
}

#endregion

#region Client actions --------------------------------------------------------

function Get-ITAction {
    <# List available device actions. #>
    $script:Actions.GetEnumerator() | ForEach-Object {
        [pscustomobject]@{ Action = $_.Key; Label = $_.Value.Label; Api = $_.Value.Api; Destructive = $_.Value.Destructive }
    }
}

function Invoke-ITDeviceAction {
    <#
    .SYNOPSIS  Run a remote action against one or many Intune devices.
    .EXAMPLE   Get-ITDevice -Name KIOSK- | Invoke-ITDeviceAction -Action Sync
    .EXAMPLE   Get-ITDevice -GroupName 'Pilot' | Invoke-ITDeviceAction -Action QuickScan -WhatIf
    .EXAMPLE   Invoke-ITDeviceAction -Id $id -Action Wipe -Confirm
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)][string[]]$Id,
        [Parameter(ValueFromPipelineByPropertyName)][string]$DeviceName,
        [Parameter(Mandatory)][ValidateScript({ $script:Actions.Contains($_) })][string]$Action,
        [switch]$Force
    )
    begin { $def = $script:Actions[$Action] }
    process {
        foreach ($i in $Id) {
            $target = if ($DeviceName) { "$DeviceName ($i)" } else { $i }
            if ($def.Destructive -and -not $Force -and -not $PSBoundParameters.ContainsKey('Confirm')) {
                $ConfirmPreference = 'Low'   # always prompt for destructive actions unless -Force
            }
            if (-not $PSCmdlet.ShouldProcess($target, $def.Label)) { continue }
            $result = [pscustomobject]@{ DeviceName = $DeviceName; Id = $i; Action = $Action; Status = 'Sent'; Message = $null }
            try {
                Invoke-ITGraph -Method POST -Api $def.Api -Uri "deviceManagement/managedDevices/$i/$($def.Path)" -Body $def.Body | Out-Null
            } catch {
                $result.Status = 'Failed'; $result.Message = $_.Exception.Message
            }
            $result
        }
    }
}

function Rename-ITDevice {
    <# Rename a Windows device (applies on next check-in, device restarts). #>
    [CmdletBinding(SupportsShouldProcess)]
    param([Parameter(Mandatory)][string]$Id, [Parameter(Mandatory)][string]$NewName)
    if ($PSCmdlet.ShouldProcess($Id, "Rename to $NewName")) {
        Invoke-ITGraph -Method POST -Api beta -Uri "deviceManagement/managedDevices/$Id/setDeviceName" -Body @{ deviceName = $NewName } | Out-Null
    }
}

function Get-ITRemediation {
    <# List Remediations (proactive remediation script packages). #>
    (Invoke-ITGraph -Api beta -Uri 'deviceManagement/deviceHealthScripts?$select=id,displayName,publisher,description' -All) |
        Select-Object displayName, publisher, id
}

function Invoke-ITRemediation {
    <# Run a Remediation script on demand on one or more devices. #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)][string[]]$Id,
        [Parameter(ValueFromPipelineByPropertyName)][string]$DeviceName,
        [Parameter(Mandatory)][string]$ScriptPolicyId
    )
    process {
        foreach ($i in $Id) {
            if (-not $PSCmdlet.ShouldProcess(($DeviceName, $i | Where-Object { $_ } | Select-Object -First 1), "Run remediation $ScriptPolicyId")) { continue }
            $r = [pscustomobject]@{ DeviceName = $DeviceName; Id = $i; Action = 'RunRemediation'; Status = 'Sent'; Message = $null }
            try {
                Invoke-ITGraph -Method POST -Api beta -Uri "deviceManagement/managedDevices/$i/initiateOnDemandProactiveRemediation" -Body @{ scriptPolicyId = $ScriptPolicyId } | Out-Null
            } catch { $r.Status = 'Failed'; $r.Message = $_.Exception.Message }
            $r
        }
    }
}

#endregion

#region Security tools --------------------------------------------------------

function Get-ITBitLockerKey {
    <# Read BitLocker recovery keys escrowed to Entra ID for a device. Audited by Entra. #>
    [CmdletBinding()]
    param([Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$AzureADDeviceId)
    process {
        $keys = (Invoke-ITGraph -Uri ("informationProtection/bitlocker/recoveryKeys?`$filter=" + [uri]::EscapeDataString("deviceId eq '$AzureADDeviceId'"))).value
        foreach ($k in @($keys)) {
            if (-not $k) { continue }
            $full = Invoke-ITGraph -Uri "informationProtection/bitlocker/recoveryKeys/$($k.id)?`$select=key"
            [pscustomobject]@{ KeyId = $k.id; VolumeType = $k.volumeType; Created = $k.createdDateTime; RecoveryKey = $full.key }
        }
    }
}

function Get-ITLapsPassword {
    <# Read the current Windows LAPS password backed up to Entra ID. Audited by Entra. #>
    [CmdletBinding()]
    param([Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$AzureADDeviceId)
    process {
        $c = Invoke-ITGraph -Uri "directory/deviceLocalCredentials/$AzureADDeviceId`?`$select=credentials"
        $latest = $c.credentials | Sort-Object backupDateTime -Descending | Select-Object -First 1
        if (-not $latest) { return }
        [pscustomobject]@{
            Account  = $latest.accountName
            Password = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($latest.passwordBase64))
            BackedUp = $latest.backupDateTime
        }
    }
}

#endregion

#region Console tools ---------------------------------------------------------

function Get-ITEntraDeviceObjectId {
    param([Parameter(Mandatory)][string]$AzureADDeviceId)
    $d = (Invoke-ITGraph -Uri ("devices?`$filter=" + [uri]::EscapeDataString("deviceId eq '$AzureADDeviceId'") + '&$select=id')).value
    if (-not $d) { throw "No Entra device object for deviceId $AzureADDeviceId" }
    $d[0].id
}

function Add-ITDeviceToGroup {
    <# Add devices to an Entra group (the "Add to collection" equivalent). #>
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$AzureADDeviceId,
        [Parameter(ValueFromPipelineByPropertyName)][string]$DeviceName,
        [Parameter(Mandatory)][string]$GroupId
    )
    process {
        $r = [pscustomobject]@{ DeviceName = $DeviceName; Id = $AzureADDeviceId; Action = 'AddToGroup'; Status = 'Added'; Message = $null }
        if (-not $PSCmdlet.ShouldProcess($DeviceName, "Add to group $GroupId")) { return }
        try {
            $oid = Get-ITEntraDeviceObjectId -AzureADDeviceId $AzureADDeviceId
            Invoke-ITGraph -Method POST -Uri "groups/$GroupId/members/`$ref" -Body @{ '@odata.id' = "$script:GraphBase/v1.0/directoryObjects/$oid" } | Out-Null
        } catch {
            if ($_.Exception.Message -match 'already exist') { $r.Status = 'AlreadyMember' } else { $r.Status = 'Failed'; $r.Message = $_.Exception.Message }
        }
        $r
    }
}

function Remove-ITDeviceFromGroup {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$AzureADDeviceId,
        [Parameter(ValueFromPipelineByPropertyName)][string]$DeviceName,
        [Parameter(Mandatory)][string]$GroupId
    )
    process {
        $r = [pscustomobject]@{ DeviceName = $DeviceName; Id = $AzureADDeviceId; Action = 'RemoveFromGroup'; Status = 'Removed'; Message = $null }
        if (-not $PSCmdlet.ShouldProcess($DeviceName, "Remove from group $GroupId")) { return }
        try {
            $oid = Get-ITEntraDeviceObjectId -AzureADDeviceId $AzureADDeviceId
            Invoke-ITGraph -Method DELETE -Uri "groups/$GroupId/members/$oid/`$ref" | Out-Null
        } catch { $r.Status = 'Failed'; $r.Message = $_.Exception.Message }
        $r
    }
}

function Find-ITGroup {
    <# Search Entra groups by display name prefix. #>
    param([Parameter(Mandatory)][string]$Name)
    (Invoke-ITGraph -Uri ("groups?`$filter=" + [uri]::EscapeDataString("startswith(displayName,'$($Name.Replace("'","''"))')") + '&$select=id,displayName,description&$top=50')).value |
        Select-Object displayName, id, description
}

function Get-ITDeviceAppStatus {
    <# Win32/LOB app install states reported for a device (beta, Windows). #>
    [CmdletBinding()]
    param([Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$Id)
    process {
        $d = Invoke-ITGraph -Api beta -Uri "deviceManagement/managedDevices/$Id`?`$select=userId"
        $uid = if ($d.userId) { $d.userId } else { '00000000-0000-0000-0000-000000000000' }
        $r = Invoke-ITGraph -Api beta -Uri "users('$uid')/mobileAppIntentAndStates('$Id')"
        $r.mobileAppList | Select-Object displayName, displayVersion, installState, mobileAppIntent
    }
}

function Get-ITDeviceComplianceDetail {
    <# Per-policy compliance state for a device. #>
    [CmdletBinding()]
    param([Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$Id)
    process {
        Invoke-ITGraph -Uri "deviceManagement/managedDevices/$Id/deviceCompliancePolicyStates" -All |
            Select-Object displayName, state, platformType, settingCount
    }
}

function Open-ITDeviceInPortal {
    <# Open the device in the Intune admin center. #>
    param([Parameter(Mandatory, ValueFromPipelineByPropertyName)][string]$Id)
    process { Start-Process "https://intune.microsoft.com/#view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/~/overview/mdmDeviceId/$Id" }
}

#endregion

Export-ModuleMember -Function @(
    'Connect-IntuneTools','Disconnect-IntuneTools','Invoke-ITGraph',
    'Get-ITDevice','Get-ITGroupManagedDevice','Get-ITDeviceDetail',
    'Get-ITAction','Invoke-ITDeviceAction','Rename-ITDevice','Get-ITRemediation','Invoke-ITRemediation',
    'Get-ITBitLockerKey','Get-ITLapsPassword',
    'Add-ITDeviceToGroup','Remove-ITDeviceFromGroup','Find-ITGroup',
    'Get-ITDeviceAppStatus','Get-ITDeviceComplianceDetail','Open-ITDeviceInPortal'
)
