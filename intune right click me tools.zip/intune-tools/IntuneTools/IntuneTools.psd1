@{
    RootModule        = 'IntuneTools.psm1'
    ModuleVersion     = '0.1.0'
    GUID              = '77671a44-595a-43b4-9310-78a4c0e49f3b'
    Author            = 'Bernard Mah'
    Copyright         = '(c) Bernard Mah. MIT License.'
    Description       = 'A light, community-style "right click tools" toolkit for Microsoft Intune, built on Microsoft Graph.'
    PowerShellVersion = '5.1'
    RequiredModules   = @()
    FunctionsToExport = @(
        'Connect-IntuneTools','Disconnect-IntuneTools','Invoke-ITGraph',
        'Get-ITDevice','Get-ITGroupManagedDevice','Get-ITDeviceDetail',
        'Get-ITAction','Invoke-ITDeviceAction','Rename-ITDevice','Get-ITRemediation','Invoke-ITRemediation',
        'Get-ITBitLockerKey','Get-ITLapsPassword',
        'Add-ITDeviceToGroup','Remove-ITDeviceFromGroup','Find-ITGroup',
        'Get-ITDeviceAppStatus','Get-ITDeviceComplianceDetail','Open-ITDeviceInPortal'
    )
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
    PrivateData       = @{
        PSData = @{
            Tags       = @('Intune','Endpoint','MicrosoftGraph','RightClickTools','MEM')
            ProjectUri = 'https://github.com/mrbernardmah/intune-tools'
            LicenseUri = 'https://github.com/mrbernardmah/intune-tools/blob/main/LICENSE'
        }
    }
}
