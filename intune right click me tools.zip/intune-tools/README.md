# Intune Right Click Tools (light)

A free, lightweight, community-style take on "right click tools" for **Microsoft Intune**.
Search for devices (or load a whole Entra group, the Intune equivalent of a ConfigMgr collection),
multi-select them, **right-click**, and run actions in bulk — no portal clicking device by device.

It is two things:

- **`IntuneRightClickTools.ps1`** — a small WPF console with a device grid and a right-click menu.
- **`IntuneTools`** — the PowerShell module underneath it, usable on its own for scripting.

Everything talks to Microsoft Graph through `Invoke-MgGraphRequest`, so the only dependency is
`Microsoft.Graph.Authentication`.

> Inspired by Recast Software's Right Click Tools Community Edition. This project is independent and is
> not affiliated with or endorsed by Recast Software.

---

## What's in the right-click menu

| Group | Action | Graph | Notes |
|---|---|---|---|
| **Client Actions** | Sync device | v1.0 `syncDevice` | |
| | Restart | v1.0 `rebootNow` | |
| | Shut down | v1.0 `shutDown` | |
| | Collect diagnostics | beta `createDeviceLogCollectionRequest` | Windows |
| | Run remediation… | beta `initiateOnDemandProactiveRemediation` | Pick from your Remediations |
| | Locate device | v1.0 `locateDevice` | Supported platforms only |
| **Defender** | Quick scan / Full scan | v1.0 `windowsDefenderScan` | |
| | Update signatures | v1.0 `windowsDefenderUpdateSignatures` | |
| **Security Tools** | Show BitLocker recovery key | v1.0 `informationProtection/bitlocker/recoveryKeys` | Audited; window auto-clears after 60s |
| | Show LAPS password | v1.0 `directory/deviceLocalCredentials` | Audited; window auto-clears after 60s |
| | Rotate BitLocker keys | beta `rotateBitLockerKeys` | |
| | Rotate LAPS password | beta `rotateLocalAdminPassword` | |
| **Console Tools** | Device details (double-click a row) | beta `managedDevices/{id}` | Hardware, storage, MACs, IDs |
| | Compliance details | v1.0 `deviceCompliancePolicyStates` | |
| | App install status | beta `mobileAppIntentAndStates` | |
| | Open in Intune admin center | — | Opens browser tab(s) |
| | Add to / Remove from Entra group… | v1.0 `groups/{id}/members` | "Add to collection" equivalent |
| | Rename device… | beta `setDeviceName` | Windows; device restarts |
| | Copy name / ID / serial, Export to CSV | — | |
| **Danger zone** | Retire, Fresh Start, Autopilot Reset, Wipe | v1.0 | You must type the action name to confirm |

Every action works on **one or many** selected devices and logs each result in the activity pane.

Ways to load devices: device name prefix (blank = all), user UPN, serial number, **Entra group**
(includes nested groups and devices of user members), or **import a CSV/TXT** list of device names.

---

## Quick start

```powershell
# 1. Get the code
git clone https://github.com/mrbernardmah/intune-tools.git
cd intune-tools

# 2. One-time: install the Graph auth module
Install-Module Microsoft.Graph.Authentication -Scope CurrentUser

# 3. Launch the console (or double-click Launch-IntuneRightClickTools.cmd)
.\IntuneRightClickTools.ps1
```

Click **Connect**, sign in, search, then right-click devices.

Options:

```powershell
.\IntuneRightClickTools.ps1 -TenantId contoso.onmicrosoft.com   # pick a tenant
.\IntuneRightClickTools.ps1 -ReadOnly                           # read scopes only; write actions greyed out
```

Requirements: Windows, Windows PowerShell 5.1 or PowerShell 7+ (the GUI uses WPF; the module itself
also runs on macOS/Linux with PowerShell 7).

---

## Using the module directly

```powershell
Import-Module .\IntuneTools\IntuneTools.psd1
Connect-IntuneTools

# Sync every device in a group
Get-ITDevice -GroupName 'Pilot - Windows' | Invoke-ITDeviceAction -Action Sync

# Quick-scan all Windows devices whose name starts with KIOSK-
Get-ITDevice -Name KIOSK- -OS Windows | Invoke-ITDeviceAction -Action QuickScan

# Dry run a destructive action
Get-ITDevice -Name LAB- | Invoke-ITDeviceAction -Action Retire -WhatIf

# Run a remediation on demand
$rem = Get-ITRemediation | Where-Object displayName -eq 'Clear Teams cache'
Get-ITDevice -User jane@contoso.com | Invoke-ITRemediation -ScriptPolicyId $rem.id

# Security lookups (audited by Entra)
Get-ITDevice -Name LAPTOP-0042 | Get-ITBitLockerKey
Get-ITDevice -Name LAPTOP-0042 | Get-ITLapsPassword

# Add devices from a list to a group
Get-Content .\devices.txt | ForEach-Object { Get-ITDevice -Name $_ } |
    Add-ITDeviceToGroup -GroupId '00000000-0000-0000-0000-000000000000'
```

Run `Get-ITAction` to list every action name. Destructive actions (`Retire`, `Wipe`, `FreshStart`,
`AutopilotReset`) always prompt unless you pass `-Force` or `-Confirm:$false`.

| Cmdlet | Purpose |
|---|---|
| `Connect-IntuneTools` / `Disconnect-IntuneTools` | Sign in / out of Graph |
| `Get-ITDevice` | Find devices by name, user, serial, Id or group |
| `Get-ITGroupManagedDevice` | Resolve an Entra group to managed devices |
| `Get-ITDeviceDetail` | Full device record with hardware info |
| `Get-ITAction` / `Invoke-ITDeviceAction` | List / run device actions |
| `Get-ITRemediation` / `Invoke-ITRemediation` | List / run Remediations on demand |
| `Rename-ITDevice` | Rename a Windows device |
| `Get-ITBitLockerKey` / `Get-ITLapsPassword` | Security lookups |
| `Find-ITGroup` / `Add-ITDeviceToGroup` / `Remove-ITDeviceFromGroup` | Group membership |
| `Get-ITDeviceComplianceDetail` / `Get-ITDeviceAppStatus` | Troubleshooting views |
| `Open-ITDeviceInPortal` | Open the device in the Intune admin center |
| `Invoke-ITGraph` | Raw Graph helper with paging |

---

## Permissions

`Connect-IntuneTools` asks for these delegated Graph scopes (an admin must consent once):

| Scope | Used for |
|---|---|
| `DeviceManagementManagedDevices.ReadWrite.All` | Read devices, sync, restart, scans, retire/wipe |
| `DeviceManagementManagedDevices.PrivilegedOperations.All` | Rotate LAPS/BitLocker, run remediation, wipe |
| `DeviceManagementConfiguration.Read.All` | List Remediations |
| `Device.Read.All` | Map Intune devices to Entra device objects |
| `GroupMember.ReadWrite.All` | Read group members, add/remove devices |
| `BitLockerKey.Read.All` | Read BitLocker recovery keys |
| `DeviceLocalCredential.Read.All` | Read Windows LAPS passwords |

With `-ReadOnly` it requests only read scopes. Your **Entra/Intune role still applies**: Graph scopes
never grant more than the signed-in admin's role allows (for example, reading BitLocker keys needs a
role such as Cloud Device Administrator or Helpdesk Administrator, and Intune remote actions are scoped
by your Intune RBAC role and scope tags).

To pass your own scopes or use device-code sign-in:

```powershell
Connect-IntuneTools -Scopes 'DeviceManagementManagedDevices.Read.All' -UseDeviceCode
```

---

## Notes and limits

- Some actions use the Graph **beta** endpoint, which Microsoft may change.
- Actions are queued by Intune; the device applies them at its next check-in. "Sent" means Graph
  accepted the request, not that the device has completed it.
- Group lookups query each member device individually, so very large groups take a while.
- The GUI runs calls on the UI thread to stay simple; it shows progress in the status bar during bulk runs.
- BitLocker key and LAPS password reads are logged in Entra audit logs and in the activity pane.

## License

MIT — see [LICENSE](LICENSE).
