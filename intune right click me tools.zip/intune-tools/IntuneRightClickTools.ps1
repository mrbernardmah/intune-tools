<#
.SYNOPSIS
    Intune Right Click Tools (light) - a WPF console with a right-click menu of
    device actions for Microsoft Intune, in the spirit of Recast Right Click Tools
    Community Edition.

.DESCRIPTION
    Search devices by name / user / serial, or load every device in an Entra group
    (the Intune equivalent of a ConfigMgr collection), multi-select them, then
    right-click to run client actions, security tools and console tools in bulk.

.EXAMPLE
    .\IntuneRightClickTools.ps1
.EXAMPLE
    .\IntuneRightClickTools.ps1 -TenantId contoso.onmicrosoft.com
#>
[CmdletBinding()]
param(
    [string]$TenantId,
    [switch]$ReadOnly
)

if (-not $IsWindows -and $PSVersionTable.PSEdition -eq 'Core') { throw 'The GUI needs Windows (WPF). Use the IntuneTools module cmdlets on other platforms.' }

# WPF needs an STA thread; relaunch if we are not on one.
if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    $exe = (Get-Process -Id $PID).Path
    $argList = @('-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    if ($TenantId) { $argList += @('-TenantId', $TenantId) }
    if ($ReadOnly) { $argList += '-ReadOnly' }
    Start-Process $exe -ArgumentList $argList
    return
}

Import-Module (Join-Path $PSScriptRoot 'IntuneTools\IntuneTools.psd1') -Force -ErrorAction Stop
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, Microsoft.VisualBasic

#region XAML -----------------------------------------------------------------
[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Intune Right Click Tools (light)" Height="720" Width="1180"
        WindowStartupLocation="CenterScreen" FontFamily="Segoe UI" FontSize="13">
  <Window.Resources>
    <Style TargetType="Button">
      <Setter Property="Padding" Value="12,4"/>
      <Setter Property="Margin" Value="4,0"/>
    </Style>
  </Window.Resources>
  <DockPanel>
    <!-- Header -->
    <Border DockPanel.Dock="Top" Background="#0F3D6E" Padding="12,8">
      <DockPanel>
        <TextBlock Text="Intune Right Click Tools" Foreground="White" FontSize="18" FontWeight="SemiBold" VerticalAlignment="Center"/>
        <TextBlock Text="  light" Foreground="#9CC3EA" FontSize="14" VerticalAlignment="Center"/>
        <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
          <TextBlock x:Name="TxtTenant" Text="Not connected" Foreground="#CFE3F7" VerticalAlignment="Center" Margin="0,0,10,0"/>
          <Button x:Name="BtnConnect" Content="Connect"/>
        </StackPanel>
      </DockPanel>
    </Border>

    <!-- Search bar -->
    <Border DockPanel.Dock="Top" Padding="10,8" Background="#F3F6FA" BorderBrush="#DDE3EA" BorderThickness="0,0,0,1">
      <StackPanel Orientation="Horizontal">
        <ComboBox x:Name="CmbMode" Width="130" SelectedIndex="0">
          <ComboBoxItem Content="Device name"/>
          <ComboBoxItem Content="User (UPN)"/>
          <ComboBoxItem Content="Serial number"/>
          <ComboBoxItem Content="Entra group"/>
        </ComboBox>
        <TextBox x:Name="TxtSearch" Width="300" Margin="6,0" VerticalContentAlignment="Center" ToolTip="Name prefix, UPN, serial, or group name. Leave blank with 'Device name' to list all."/>
        <ComboBox x:Name="CmbOS" Width="100" SelectedIndex="0">
          <ComboBoxItem Content="Any"/>
          <ComboBoxItem Content="Windows"/>
          <ComboBoxItem Content="macOS"/>
          <ComboBoxItem Content="iOS"/>
          <ComboBoxItem Content="Android"/>
        </ComboBox>
        <Button x:Name="BtnSearch" Content="Search" IsDefault="True"/>
        <Button x:Name="BtnImport" Content="Import names (CSV/TXT)" ToolTip="One device name per line, or a CSV with a DeviceName column"/>
        <Button x:Name="BtnClear" Content="Clear"/>
      </StackPanel>
    </Border>

    <!-- Status bar -->
    <StatusBar DockPanel.Dock="Bottom">
      <StatusBarItem><TextBlock x:Name="TxtStatus" Text="Ready"/></StatusBarItem>
      <StatusBarItem HorizontalAlignment="Right"><TextBlock x:Name="TxtCount" Text="0 devices"/></StatusBarItem>
    </StatusBar>

    <!-- Log -->
    <Expander DockPanel.Dock="Bottom" Header="Activity log" IsExpanded="True">
      <TextBox x:Name="TxtLog" Height="150" IsReadOnly="True" FontFamily="Consolas" FontSize="12"
               VerticalScrollBarVisibility="Auto" TextWrapping="NoWrap" HorizontalScrollBarVisibility="Auto"/>
    </Expander>

    <!-- Device grid -->
    <DataGrid x:Name="Grid" AutoGenerateColumns="False" IsReadOnly="True" SelectionMode="Extended"
              CanUserSortColumns="True" GridLinesVisibility="Horizontal" HeadersVisibility="Column"
              AlternatingRowBackground="#F8FAFC" Margin="0">
      <DataGrid.Columns>
        <DataGridTextColumn Header="Device name" Binding="{Binding DeviceName}" Width="180"/>
        <DataGridTextColumn Header="User" Binding="{Binding User}" Width="220"/>
        <DataGridTextColumn Header="OS" Binding="{Binding OS}" Width="80"/>
        <DataGridTextColumn Header="Version" Binding="{Binding OSVersion}" Width="120"/>
        <DataGridTextColumn Header="Compliance" Binding="{Binding Compliance}" Width="100"/>
        <DataGridTextColumn Header="Last sync" Binding="{Binding LastSync, StringFormat='yyyy-MM-dd HH:mm'}" Width="130"/>
        <DataGridTextColumn Header="Ownership" Binding="{Binding Ownership}" Width="85"/>
        <DataGridTextColumn Header="Model" Binding="{Binding Model}" Width="160"/>
        <DataGridTextColumn Header="Serial" Binding="{Binding SerialNumber}" Width="120"/>
        <DataGridTextColumn Header="Encrypted" Binding="{Binding Encrypted}" Width="75"/>
      </DataGrid.Columns>
      <DataGrid.ContextMenu>
        <ContextMenu x:Name="Ctx">
          <MenuItem Header="Client Actions">
            <MenuItem Header="Sync device"            Tag="act:Sync"/>
            <MenuItem Header="Restart"                Tag="act:Restart"/>
            <MenuItem Header="Shut down"              Tag="act:Shutdown"/>
            <MenuItem Header="Collect diagnostics"    Tag="act:CollectDiagnostics"/>
            <MenuItem Header="Run remediation..."     Tag="tool:RunRemediation"/>
            <MenuItem Header="Locate device"          Tag="act:Locate"/>
          </MenuItem>
          <MenuItem Header="Defender">
            <MenuItem Header="Quick scan"             Tag="act:QuickScan"/>
            <MenuItem Header="Full scan"              Tag="act:FullScan"/>
            <MenuItem Header="Update signatures"      Tag="act:UpdateDefender"/>
          </MenuItem>
          <MenuItem Header="Security Tools">
            <MenuItem Header="Show BitLocker recovery key" Tag="tool:BitLocker"/>
            <MenuItem Header="Show LAPS password"          Tag="tool:LAPS"/>
            <Separator/>
            <MenuItem Header="Rotate BitLocker keys"  Tag="act:RotateBitLocker"/>
            <MenuItem Header="Rotate LAPS password"   Tag="act:RotateLAPS"/>
          </MenuItem>
          <MenuItem Header="Console Tools">
            <MenuItem Header="Device details"         Tag="tool:Details"/>
            <MenuItem Header="Compliance details"     Tag="tool:Compliance"/>
            <MenuItem Header="App install status"     Tag="tool:Apps"/>
            <MenuItem Header="Open in Intune admin center" Tag="tool:Portal"/>
            <Separator/>
            <MenuItem Header="Add to Entra group..."      Tag="tool:AddGroup"/>
            <MenuItem Header="Remove from Entra group..." Tag="tool:RemoveGroup"/>
            <MenuItem Header="Rename device..."           Tag="tool:Rename"/>
            <Separator/>
            <MenuItem Header="Copy device name(s)"    Tag="tool:CopyName"/>
            <MenuItem Header="Copy Intune device ID(s)" Tag="tool:CopyId"/>
            <MenuItem Header="Copy serial number(s)"  Tag="tool:CopySerial"/>
            <MenuItem Header="Export selected to CSV" Tag="tool:Export"/>
          </MenuItem>
          <Separator/>
          <MenuItem Header="Danger zone" Foreground="#B42318">
            <MenuItem Header="Retire"                       Tag="act:Retire"/>
            <MenuItem Header="Fresh Start (keep user data)" Tag="act:FreshStart"/>
            <MenuItem Header="Autopilot Reset"              Tag="act:AutopilotReset"/>
            <MenuItem Header="Wipe (factory reset)"         Tag="act:Wipe"/>
          </MenuItem>
          <Separator/>
          <MenuItem Header="Refresh" Tag="tool:Refresh"/>
        </ContextMenu>
      </DataGrid.ContextMenu>
    </DataGrid>
  </DockPanel>
</Window>
'@
#endregion

$reader = [System.Xml.XmlNodeReader]::new($xaml)
$win    = [Windows.Markup.XamlReader]::Load($reader)
$ui = @{}
$xaml.SelectNodes('//*[@*[local-name()="Name"]]') | ForEach-Object {
    $n = $_.Attributes | Where-Object LocalName -eq 'Name' | Select-Object -First 1 -ExpandProperty Value
    $ui[$n] = $win.FindName($n)
}

$script:Devices = [System.Collections.ObjectModel.ObservableCollection[object]]::new()
$ui.Grid.ItemsSource = $script:Devices
$script:LastQuery = $null

#region UI helpers ------------------------------------------------------------
function Update-UI { $win.Dispatcher.Invoke([Action]{}, [Windows.Threading.DispatcherPriority]::Background) }

function Write-Log([string]$Message, [string]$Level = 'INFO') {
    $line = '{0:HH:mm:ss} [{1}] {2}' -f (Get-Date), $Level, $Message
    $ui.TxtLog.AppendText($line + [Environment]::NewLine)
    $ui.TxtLog.ScrollToEnd()
    Update-UI
}

function Set-Status([string]$Text) { $ui.TxtStatus.Text = $Text; Update-UI }
function Set-Busy([bool]$Busy) {
    $win.Cursor = if ($Busy) { [Windows.Input.Cursors]::Wait } else { $null }
    $ui.BtnSearch.IsEnabled = -not $Busy
    Update-UI
}

function Show-Message([string]$Text, [string]$Title = 'Intune Right Click Tools', [string]$Icon = 'Information') {
    [void][Windows.MessageBox]::Show($win, $Text, $Title, 'OK', $Icon)
}

function Read-Input([string]$Prompt, [string]$Title = 'Intune Right Click Tools', [string]$Default = '') {
    [Microsoft.VisualBasic.Interaction]::InputBox($Prompt, $Title, $Default)
}

function Get-Selected { @($ui.Grid.SelectedItems) }

function Show-TextWindow([string]$Title, [string]$Text, [switch]$Sensitive) {
    $w = [Windows.Window]@{ Title = $Title; Width = 640; Height = 420; WindowStartupLocation = 'CenterOwner'; Owner = $win; FontFamily = 'Segoe UI' }
    $dock = [Windows.Controls.DockPanel]::new()
    $bar  = [Windows.Controls.StackPanel]@{ Orientation = 'Horizontal'; HorizontalAlignment = 'Right'; Margin = '8' }
    $copy = [Windows.Controls.Button]@{ Content = 'Copy'; Padding = '12,4'; Margin = '4,0' }
    $close = [Windows.Controls.Button]@{ Content = 'Close'; Padding = '12,4'; Margin = '4,0'; IsCancel = $true }
    $box  = [Windows.Controls.TextBox]@{ Text = $Text; IsReadOnly = $true; FontFamily = 'Consolas'; FontSize = 13; TextWrapping = 'Wrap'; VerticalScrollBarVisibility = 'Auto'; Margin = '8,8,8,0' }
    $copy.Add_Click({ [Windows.Clipboard]::SetText($box.Text) }.GetNewClosure())
    $close.Add_Click({ $w.Close() }.GetNewClosure())
    [void]$bar.Children.Add($copy); [void]$bar.Children.Add($close)
    [Windows.Controls.DockPanel]::SetDock($bar, 'Bottom')
    [void]$dock.Children.Add($bar); [void]$dock.Children.Add($box)
    if ($Sensitive) {
        $note = [Windows.Controls.TextBlock]@{ Text = 'Sensitive: this retrieval is audited in Entra ID. The window clears in 60 seconds.'; Foreground = '#B42318'; Margin = '8,8,8,0' }
        [Windows.Controls.DockPanel]::SetDock($note, 'Top'); $dock.Children.Insert(0, $note)
        $t = [Windows.Threading.DispatcherTimer]@{ Interval = [TimeSpan]::FromSeconds(60) }
        $t.Add_Tick({ $t.Stop(); $box.Text = '(cleared)' }.GetNewClosure()); $t.Start()
        $w.Add_Closed({ $t.Stop() }.GetNewClosure())
    }
    $w.Content = $dock
    [void]$w.ShowDialog()
}

function Show-Picker([object[]]$Items, [string]$Title, [string]$DisplayProperty) {
    # Simple filterable single-select list. Returns the chosen item or $null.
    $w = [Windows.Window]@{ Title = $Title; Width = 520; Height = 480; WindowStartupLocation = 'CenterOwner'; Owner = $win; FontFamily = 'Segoe UI' }
    $dock = [Windows.Controls.DockPanel]::new()
    $filter = [Windows.Controls.TextBox]@{ Margin = '8'; ToolTip = 'Filter' }
    $list = [Windows.Controls.ListBox]@{ Margin = '8,0,8,0'; DisplayMemberPath = $DisplayProperty }
    $bar  = [Windows.Controls.StackPanel]@{ Orientation = 'Horizontal'; HorizontalAlignment = 'Right'; Margin = '8' }
    $ok   = [Windows.Controls.Button]@{ Content = 'OK'; Padding = '14,4'; Margin = '4,0'; IsDefault = $true }
    $cancel = [Windows.Controls.Button]@{ Content = 'Cancel'; Padding = '14,4'; Margin = '4,0'; IsCancel = $true }
    $state = @{ Result = $null }
    $list.ItemsSource = $Items
    $filter.Add_TextChanged({
        $f = $filter.Text
        $list.ItemsSource = if ($f) { @($Items | Where-Object { $_.$DisplayProperty -like "*$f*" }) } else { $Items }
    }.GetNewClosure())
    $ok.Add_Click({ $state.Result = $list.SelectedItem; $w.Close() }.GetNewClosure())
    $list.Add_MouseDoubleClick({ $state.Result = $list.SelectedItem; $w.Close() }.GetNewClosure())
    [void]$bar.Children.Add($ok); [void]$bar.Children.Add($cancel)
    [Windows.Controls.DockPanel]::SetDock($filter, 'Top'); [Windows.Controls.DockPanel]::SetDock($bar, 'Bottom')
    [void]$dock.Children.Add($filter); [void]$dock.Children.Add($bar); [void]$dock.Children.Add($list)
    $w.Content = $dock
    $filter.Focus() | Out-Null
    [void]$w.ShowDialog()
    $state.Result
}

function Select-Group([string]$Title) {
    $q = Read-Input 'Group name starts with:' $Title
    if (-not $q) { return $null }
    $groups = @(Find-ITGroup -Name $q)
    if (-not $groups) { Show-Message "No groups found starting with '$q'."; return $null }
    Show-Picker -Items $groups -Title $Title -DisplayProperty 'displayName'
}

function Set-Devices([object[]]$List) {
    $script:Devices.Clear()
    foreach ($d in $List) { $script:Devices.Add($d) }
    $ui.TxtCount.Text = "$($script:Devices.Count) devices"
}

function Invoke-Guarded([scriptblock]$Block) {
    if (-not (Get-MgContext -ErrorAction SilentlyContinue)) { Show-Message 'Connect first.'; return }
    Set-Busy $true
    try { & $Block } catch { Write-Log $_.Exception.Message 'ERROR'; Show-Message $_.Exception.Message 'Error' 'Error' }
    finally { Set-Busy $false; Set-Status 'Ready' }
}
#endregion

#region Search ----------------------------------------------------------------
function Invoke-Search {
    $mode = $ui.CmbMode.SelectedIndex
    $text = $ui.TxtSearch.Text.Trim()
    $os   = $ui.CmbOS.SelectedItem.Content
    $script:LastQuery = @{ Mode = $mode; Text = $text; OS = $os }
    Invoke-Guarded {
        Set-Status 'Searching...'
        $res = switch ($mode) {
            0 { Get-ITDevice -Name $text -OS $os }
            1 { if (-not $text) { throw 'Enter a UPN.' };    Get-ITDevice -User $text -OS $os }
            2 { if (-not $text) { throw 'Enter a serial.' }; Get-ITDevice -SerialNumber $text }
            3 { if (-not $text) { throw 'Enter a group name.' }
                $g = @(Find-ITGroup -Name $text)
                $pick = if ($g.Count -eq 1) { $g[0] } elseif ($g.Count -gt 1) { Show-Picker -Items $g -Title 'Choose group' -DisplayProperty 'displayName' } else { throw "No group starting with '$text'." }
                if (-not $pick) { return }
                Write-Log "Resolving members of group '$($pick.displayName)'..."
                $d = @(Get-ITGroupManagedDevice -GroupId $pick.id)
                if ($os -ne 'Any') { $d = @($d | Where-Object OS -eq $os) }
                $d }
        }
        Set-Devices @($res)
        Write-Log "Found $(@($res).Count) device(s)."
    }
}

function Import-DeviceList {
    $dlg = [Microsoft.Win32.OpenFileDialog]@{ Filter = 'CSV or text (*.csv;*.txt)|*.csv;*.txt|All files|*.*' }
    if (-not $dlg.ShowDialog($win)) { return }
    $path = $dlg.FileName
    $names = if ($path -like '*.csv') {
        $rows = Import-Csv $path
        $col = @('DeviceName','Device name','Name','ComputerName') | Where-Object { $rows[0].PSObject.Properties[$_] } | Select-Object -First 1
        if (-not $col) { Show-Message 'CSV needs a DeviceName column.'; return }
        $rows.$col
    } else { Get-Content $path }
    $names = @($names | ForEach-Object { "$_".Trim() } | Where-Object { $_ } | Select-Object -Unique)
    Invoke-Guarded {
        $found = [System.Collections.Generic.List[object]]::new()
        $n = 0
        foreach ($name in $names) {
            $n++; Set-Status "Looking up $n / $($names.Count): $name"
            $hit = @(Get-ITDevice -Name $name | Where-Object DeviceName -eq $name)
            if ($hit) { $hit | ForEach-Object { $found.Add($_) } } else { Write-Log "Not found: $name" 'WARN' }
        }
        Set-Devices $found
        Write-Log "Imported $($found.Count) of $($names.Count) device(s) from $(Split-Path $path -Leaf)."
    }
}
#endregion

#region Actions ---------------------------------------------------------------
$script:ActionDefs = @{}
Get-ITAction | ForEach-Object { $script:ActionDefs[$_.Action] = $_ }

function Invoke-BulkAction([string]$Action) {
    $sel = Get-Selected
    if (-not $sel) { Show-Message 'Select one or more devices first.'; return }
    $def = $script:ActionDefs[$Action]
    $names = ($sel | Select-Object -First 10 -ExpandProperty DeviceName) -join ', '
    if ($sel.Count -gt 10) { $names += ", ... (+$($sel.Count - 10) more)" }

    if ($def.Destructive) {
        $word = $Action.ToUpper()
        $typed = Read-Input ("{0} on {1} device(s):`n{2}`n`nThis cannot be undone. Type {3} to confirm." -f $def.Label, $sel.Count, $names, $word) 'Confirm destructive action'
        if ($typed -cne $word) { Write-Log "$($def.Label) cancelled."; return }
    } else {
        $r = [Windows.MessageBox]::Show($win, ("{0} on {1} device(s)?`n`n{2}" -f $def.Label, $sel.Count, $names), 'Confirm', 'YesNo', 'Question')
        if ($r -ne 'Yes') { return }
    }

    Invoke-Guarded {
        $ok = 0; $fail = 0; $i = 0
        foreach ($d in $sel) {
            $i++; Set-Status "$($def.Label): $i / $($sel.Count)"
            $res = Invoke-ITDeviceAction -Id $d.Id -DeviceName $d.DeviceName -Action $Action -Force -Confirm:$false
            if ($res.Status -eq 'Sent') { $ok++; Write-Log "$($def.Label) -> $($d.DeviceName): sent" }
            else { $fail++; Write-Log "$($def.Label) -> $($d.DeviceName): $($res.Message)" 'ERROR' }
        }
        Write-Log "$($def.Label) finished: $ok sent, $fail failed."
    }
}

function Invoke-Tool([string]$Tool) {
    $sel = Get-Selected
    $needsSel = $Tool -notin @('Refresh')
    if ($needsSel -and -not $sel) { Show-Message 'Select one or more devices first.'; return }
    $one = $sel | Select-Object -First 1

    switch ($Tool) {
        'Refresh' { if ($script:LastQuery) { Invoke-Search } }

        'CopyName'   { [Windows.Clipboard]::SetText(($sel.DeviceName -join [Environment]::NewLine)); Write-Log "Copied $($sel.Count) name(s)." }
        'CopyId'     { [Windows.Clipboard]::SetText(($sel.Id -join [Environment]::NewLine)); Write-Log "Copied $($sel.Count) ID(s)." }
        'CopySerial' { [Windows.Clipboard]::SetText(($sel.SerialNumber -join [Environment]::NewLine)); Write-Log "Copied $($sel.Count) serial(s)." }

        'Export' {
            $dlg = [Microsoft.Win32.SaveFileDialog]@{ Filter = 'CSV (*.csv)|*.csv'; FileName = "IntuneDevices_{0:yyyyMMdd_HHmm}.csv" -f (Get-Date) }
            if ($dlg.ShowDialog($win)) { $sel | Export-Csv $dlg.FileName -NoTypeInformation -Encoding UTF8; Write-Log "Exported $($sel.Count) device(s) to $($dlg.FileName)" }
        }

        'Portal' {
            if ($sel.Count -gt 5 -and [Windows.MessageBox]::Show($win, "Open $($sel.Count) browser tabs?", 'Confirm', 'YesNo') -ne 'Yes') { return }
            $sel | ForEach-Object { Open-ITDeviceInPortal -Id $_.Id }
        }

        'Details' { Invoke-Guarded {
            $d = Get-ITDeviceDetail -Id $one.Id
            $hw = $d.hardwareInformation
            $txt = @(
                "Device name     : $($d.deviceName)"
                "Primary user    : $($d.userPrincipalName)  ($($d.userDisplayName))"
                "OS              : $($d.operatingSystem) $($d.osVersion)"
                "Compliance      : $($d.complianceState)"
                "Management      : $($d.managementAgent) / $($d.managementState)"
                "Ownership       : $($d.managedDeviceOwnerType)"
                "Enrolled        : $($d.enrolledDateTime)"
                "Last sync       : $($d.lastSyncDateTime)"
                "Join type       : $($d.joinType)"
                "Autopilot       : $($d.autopilotEnrolled)"
                "Manufacturer    : $($d.manufacturer)"
                "Model           : $($d.model)"
                "Serial          : $($d.serialNumber)"
                "Storage         : {0:N1} GB free of {1:N1} GB" -f ($d.freeStorageSpaceInBytes / 1GB), ($d.totalStorageSpaceInBytes / 1GB)
                "Memory          : {0:N1} GB" -f ($d.physicalMemoryInBytes / 1GB)
                "Encrypted       : $($d.isEncrypted)"
                "TPM version     : $($hw.tpmVersion)"
                "Wi-Fi MAC       : $($d.wiFiMacAddress)"
                "Ethernet MAC    : $($d.ethernetMacAddress)"
                "IPv4            : $($hw.ipAddressV4)"
                "Intune ID       : $($d.id)"
                "Entra device ID : $($d.azureADDeviceId)"
            ) -join [Environment]::NewLine
            Show-TextWindow "Device details - $($one.DeviceName)" $txt
        } }

        'Compliance' { Invoke-Guarded {
            $p = Get-ITDeviceComplianceDetail -Id $one.Id
            $txt = ($p | Format-Table -AutoSize | Out-String -Width 200).Trim()
            if (-not $txt) { $txt = 'No compliance policy states reported.' }
            Show-TextWindow "Compliance - $($one.DeviceName)" $txt
        } }

        'Apps' { Invoke-Guarded {
            Set-Status 'Reading app status...'
            $a = Get-ITDeviceAppStatus -Id $one.Id | Sort-Object displayName
            $txt = ($a | Format-Table -AutoSize | Out-String -Width 220).Trim()
            if (-not $txt) { $txt = 'No app install states reported.' }
            Show-TextWindow "App install status - $($one.DeviceName)" $txt
        } }

        'BitLocker' { Invoke-Guarded {
            if (-not $one.AzureADDeviceId) { throw 'Device has no Entra device ID.' }
            $k = @(Get-ITBitLockerKey -AzureADDeviceId $one.AzureADDeviceId)
            Write-Log "Retrieved BitLocker key(s) for $($one.DeviceName)." 'AUDIT'
            $txt = if ($k) { ($k | ForEach-Object { "Key ID   : $($_.KeyId)`nVolume   : $($_.VolumeType)`nCreated  : $($_.Created)`nRecovery : $($_.RecoveryKey)`n" }) -join "`n" } else { 'No recovery keys escrowed for this device.' }
            Show-TextWindow "BitLocker - $($one.DeviceName)" $txt -Sensitive
        } }

        'LAPS' { Invoke-Guarded {
            if (-not $one.AzureADDeviceId) { throw 'Device has no Entra device ID.' }
            $c = Get-ITLapsPassword -AzureADDeviceId $one.AzureADDeviceId
            Write-Log "Retrieved LAPS password for $($one.DeviceName)." 'AUDIT'
            $txt = if ($c) { "Account   : $($c.Account)`nPassword  : $($c.Password)`nBacked up : $($c.BackedUp)" } else { 'No LAPS password backed up for this device.' }
            Show-TextWindow "LAPS - $($one.DeviceName)" $txt -Sensitive
        } }

        'RunRemediation' { Invoke-Guarded {
            $scripts = @(Get-ITRemediation | Sort-Object displayName)
            if (-not $scripts) { throw 'No remediation scripts found in this tenant.' }
            $pick = Show-Picker -Items $scripts -Title 'Choose a remediation to run' -DisplayProperty 'displayName'
            if (-not $pick) { return }
            if ([Windows.MessageBox]::Show($win, "Run '$($pick.displayName)' on $($sel.Count) device(s)?", 'Confirm', 'YesNo') -ne 'Yes') { return }
            foreach ($d in $sel) {
                $r = Invoke-ITRemediation -Id $d.Id -DeviceName $d.DeviceName -ScriptPolicyId $pick.id -Confirm:$false
                Write-Log ("Remediation '{0}' -> {1}: {2} {3}" -f $pick.displayName, $d.DeviceName, $r.Status, $r.Message) $(if ($r.Status -eq 'Sent') { 'INFO' } else { 'ERROR' })
            }
        } }

        'AddGroup' { Invoke-Guarded {
            $g = Select-Group 'Add to Entra group'
            if (-not $g) { return }
            foreach ($d in $sel) {
                $r = Add-ITDeviceToGroup -AzureADDeviceId $d.AzureADDeviceId -DeviceName $d.DeviceName -GroupId $g.id -Confirm:$false
                Write-Log "Add $($d.DeviceName) to '$($g.displayName)': $($r.Status) $($r.Message)"
            }
        } }

        'RemoveGroup' { Invoke-Guarded {
            $g = Select-Group 'Remove from Entra group'
            if (-not $g) { return }
            if ([Windows.MessageBox]::Show($win, "Remove $($sel.Count) device(s) from '$($g.displayName)'?", 'Confirm', 'YesNo') -ne 'Yes') { return }
            foreach ($d in $sel) {
                $r = Remove-ITDeviceFromGroup -AzureADDeviceId $d.AzureADDeviceId -DeviceName $d.DeviceName -GroupId $g.id -Confirm:$false
                Write-Log "Remove $($d.DeviceName) from '$($g.displayName)': $($r.Status) $($r.Message)"
            }
        } }

        'Rename' { Invoke-Guarded {
            if ($sel.Count -ne 1) { throw 'Select exactly one device to rename.' }
            $new = Read-Input "New name for $($one.DeviceName) (max 15 chars for Windows).`nThe device restarts to apply it." 'Rename device' $one.DeviceName
            if (-not $new -or $new -eq $one.DeviceName) { return }
            Rename-ITDevice -Id $one.Id -NewName $new -Confirm:$false
            Write-Log "Rename $($one.DeviceName) -> ${new}: sent"
        } }
    }
}
#endregion

#region Wire-up ---------------------------------------------------------------
$ui.BtnConnect.Add_Click({
    try {
        Set-Busy $true; Set-Status 'Signing in...'
        $p = @{}
        if ($TenantId) { $p.TenantId = $TenantId }
        if ($ReadOnly) { $p.ReadOnly = $true }
        $ctx = Connect-IntuneTools @p
        $ui.TxtTenant.Text = "$($ctx.Account)  |  $($ctx.TenantId)"
        $ui.BtnConnect.Content = 'Reconnect'
        Write-Log "Connected as $($ctx.Account)."
    } catch { Write-Log $_.Exception.Message 'ERROR'; Show-Message $_.Exception.Message 'Sign-in failed' 'Error' }
    finally { Set-Busy $false; Set-Status 'Ready' }
})
$ui.BtnSearch.Add_Click({ Invoke-Search })
$ui.BtnImport.Add_Click({ Import-DeviceList })
$ui.BtnClear.Add_Click({ Set-Devices @(); $ui.TxtSearch.Clear() })
$ui.Grid.Add_MouseDoubleClick({ if ($ui.Grid.SelectedItem) { Invoke-Tool 'Details' } })

# One click handler for every leaf menu item, routed by its Tag.
function Register-MenuItems($items) {
    foreach ($mi in $items) {
        if ($mi -isnot [Windows.Controls.MenuItem]) { continue }
        if ($mi.Items.Count -gt 0) { Register-MenuItems $mi.Items; continue }
        $mi.Add_Click({
            param($s, $e)
            $kind, $name = "$($s.Tag)" -split ':', 2
            if ($kind -eq 'act') { Invoke-BulkAction $name } else { Invoke-Tool $name }
        })
    }
}
Register-MenuItems $ui.Ctx.Items

# Read-only sessions: grey out anything that writes.
$ui.Ctx.Add_Opened({
    $ro = [bool]$ReadOnly
    $writes = '^(act:|tool:(RunRemediation|AddGroup|RemoveGroup|Rename|BitLocker|LAPS))'
    $walk = { param($items) foreach ($m in $items) { if ($m -is [Windows.Controls.MenuItem]) { if ($m.Items.Count) { & $walk $m.Items } elseif ("$($m.Tag)" -match $writes) { $m.IsEnabled = -not $ro } } } }
    & $walk $ui.Ctx.Items
})

$win.Add_ContentRendered({ Write-Log 'Ready. Click Connect to sign in to Microsoft Graph, then search and right-click devices.' })
#endregion

[void]$win.ShowDialog()
