@echo off
rem Launch Intune Right Click Tools. Prefers PowerShell 7 if installed.
where pwsh >nul 2>nul
if %errorlevel%==0 (
  start "" pwsh -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0IntuneRightClickTools.ps1" %*
) else (
  start "" powershell -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0IntuneRightClickTools.ps1" %*
)
